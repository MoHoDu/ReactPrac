function History() {
  return <div></div>;
}

export default History;
